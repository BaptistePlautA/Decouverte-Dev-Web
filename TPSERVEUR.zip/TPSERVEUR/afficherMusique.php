<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="PROJETSERVEUR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="Musimax.css">
		<link rel="stylesheet" href="form.css"
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>MUSIMAX : MA MUSIQUE EN LIGNE</title>
  </head>

<header>
<center><h1> MUSIMAX VOTRE PLATEFORME DE MUSIQUE GRATUITE </h1></center>
</header>

<body>
	<div class="wrapper">
		<h2 class="title">VOS CHOIX</h2>
		<div class="container-fluid">
			<div class="block_line">

				<div class="container-box1 block" id="box"> <!-- PREMIERE BOX -->
          <h2>Musiques</h2>
  	      <a href="rechercherDesMusiques.php">Retour</a>
				</div> <!-- FIN PREMIERE BOX -->
			</div>
		</div>
	</div>
</body>
</html>

