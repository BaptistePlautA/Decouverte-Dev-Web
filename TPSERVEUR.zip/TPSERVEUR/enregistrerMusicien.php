<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="PROJETSERVEUR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="Musimax.css">
		<link rel="stylesheet" href="form.css"
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>MUSIMAX : MA MUSIQUE EN LIGNE</title>
  </head>

<header>
<center><h1> MUSIMAX VOTRE PLATEFORME DE MUSIQUE GRATUITE </h1></center>
<center><a href="Musimax_ADMIN.html" class="connexion-btn">Revenir à l'accueil</a></center>
</header>

<body>
  <div class="wrapper">
		<h2 class="title">VOS CHOIX</h2>
		<div class="container-fluid">
			<div class="block_line">

				<div class="container-box1 block" id="box"> <!-- PREMIERE BOX -->
                <?php
                    if (isset($_POST['nom']) && isset($_POST['date']) && isset($_POST['albums'])) {
                        $nom = $_POST['nom'];
                        $date = $_POST['date'];
                        $albums = $_POST['albums'];

                        // Ouvrir le fichier CSV en mode écriture
                        $fichier = fopen('infoMusiciens.csv', 'a');

                        // Écrire les informations du musicien dans le fichier CSV
                        fwrite($fichier, "$nom;$date;$albums\n");

                        // Fermer le fichier CSV
                        fclose($fichier);
                    }

                    // Afficher la liste des artistes/groupes déjà enregistrés
                    $fichier = fopen('infoMusiciens.csv', 'r');

                    echo '<h1>Vos Artistes/Groupe de musique</h1>';
                    echo '<ul>';

                    while (($ligne = fgets($fichier)) !== false) {
                        $infos = explode(';', $ligne);
                        $nom = $infos[0];
                        echo "<li>$nom</li>";
                    }

                    echo '</ul>';

                    fclose($fichier);
                    ?>
				</div> <!-- FIN PREMIERE BOX -->
			</div>
		</div>
	</div>
</body>
</html>

