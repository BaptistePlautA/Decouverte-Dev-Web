<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="PROJETSERVEUR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="Musimax.css">
    <link rel="stylesheet" href="connexion.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>Connexion</title>
  </head>

<header>
  <center><h1> MUSIMAX VOTRE PLATEFORME DE MUSIQUE GRATUITE </h1>
</header>

  <body>
      <div class="background">
          <div class="shape"></div>
          <div class="shape"></div>
      </div>
      <form action="verificationConnexion.php" method="post">
            <h3>Connexion</h3>
            <label for="identifiant">Identifiant :</label>
            <input type="text" name="identifiant" id="identifiant" required><br><br>

            <label for="motdepasse">Mot de passe :</label>
            <input type="password" name="motdepasse" id="motdepasse" required><br><br>
            <input type="submit" value="Se connecter">      
          </form>
  </body>
</html>
