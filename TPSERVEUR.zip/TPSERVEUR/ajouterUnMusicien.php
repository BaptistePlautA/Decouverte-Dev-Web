<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="PROJETSERVEUR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="Musimax.css">
		<link rel="stylesheet" href="form.css"
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>MUSIMAX : MA MUSIQUE EN LIGNE</title>
  </head>

<header>
<center><h1> MUSIMAX VOTRE PLATEFORME DE MUSIQUE GRATUITE </h1></center>
</header>

<body>
	<div class="wrapper">
		<h2 class="title">VOS CHOIX</h2>
		<div class="container-fluid">
			<div class="block_line">

				<div class="container-box1 block" id="box"> <!-- PREMIERE BOX -->
								<form action="enregistrerMusicien.php" method="post">
									<h2>Ajouter un musicien</h2>
									<label for="nom">Nom :</label>
									<input type="text" id="nom" name="nom" required><br><br>
									<label for="date">Date de formation :</label>
									<input type="date" id="date" name="date" required><br><br>
									<label for="albums">Nombre d'albums :</label>
									<input type="number" id="albums" name="albums" required><br><br>
									<input type="submit" value="Ajouter">
								</form>
				</div> <!-- FIN PREMIERE BOX -->
			</div>
		</div>
	</div>
</body>
</html>
