<?php
        // Vérification des identifiants
        $identifiant = $_POST['identifiant'];
        $motdepasse = $_POST['motdepasse'];

        $fichier = fopen('identifiant.csv', 'r');
        $trouve = false;

        ///On check id + mdp et on redirige en fonction du profil
        while (($ligne = fgetcsv($fichier, 1000, ';')) !== false) {
            if ($ligne[0] == $identifiant && $ligne[1] == $motdepasse) {
                $trouve = true;
                $profil = $ligne[2];
                break;
            }
        }

        fclose($fichier);

        if ($trouve) {
            // Redirection en fonction du profil
            if ($profil == 'administrateur') {
                header('Location: Musimax_ADMIN.html');
                exit();
            } elseif ($profil == 'utilisateur') {
                header('Location: rechercherDesMusiques.php');
                exit();
            }
        } else {
            // Identifiants incorrects => Retour sur la page de connexion
            header('Location: connexion.php');
            exit();
        }
?>

<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="PROJETSERVEUR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="Musimax.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>MUSIMAX : MA MUSIQUE EN LIGNE</title>
  </head>

  <body style="color:white">
    Vérification des identifiants...
  </body>
</html>



