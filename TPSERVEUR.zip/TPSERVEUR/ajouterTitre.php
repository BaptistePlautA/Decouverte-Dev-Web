<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="PROJETSERVEUR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="Musimax.css">
		<link rel="stylesheet" href="form.css"
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>MUSIMAX : MA MUSIQUE EN LIGNE</title>
  </head>

<header>
<center><h1> MUSIMAX VOTRE PLATEFORME DE MUSIQUE GRATUITE </h1></center>
</header>

<body>
  <div class="wrapper">
		<h2 class="title">VOS CHOIX</h2>
		<div class="container-fluid">
			<div class="block_line">

				<div class="container-box1 block" id="box"> <!-- PREMIERE BOX -->
          <form action="enregistrerTitre.php" method="post">
          		<label for="nomArtiste">Artiste/Groupe :</label>
          		<select name="nomArtiste" id="nomArtiste">
					<?php
						// On récupère la liste des artistes enregistrés dans le fichier infoMusiciens.csv
						$fichierArtistes = fopen("infoMusiciens.csv", "r");
						$listeArtistes = array();
						while (($ligne = fgetcsv($fichierArtistes)) !== false) {
							$listeArtistes[] = $ligne[0];
						}
						fclose($fichierArtistes);

						// On génère les options de la liste déroulante
						foreach ($listeArtistes as $artiste) {
							echo '<option value="' . $artiste . '">' . $artiste . '</option>';
						}
					?>
          		</select>
          		<br><br>
          		<label for="titre">Titre :</label>
          		<input type="text" name="titre" id="titre">
          		<br><br>
          		<label for="duree">Durée (en secondes) :</label>
          		<input type="number" name="duree" id="duree">
          		<br><br>
          		<input type="submit" value="Enregistrer">
          	</form>
				</div> <!-- FIN PREMIERE BOX -->
			</div>
		</div>
	</div>
</body>
</html>

