!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="description" content="PROJETSERVEUR">
    <meta name="author" content="PLAUT-AUBRY Baptiste">
    <link rel="stylesheet" href="Musimax.css">
		<link rel="stylesheet" href="form.css"
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <title>MUSIMAX : MA MUSIQUE EN LIGNE</title>
  </head>

<header>
<center><h1> MUSIMAX VOTRE PLATEFORME DE MUSIQUE GRATUITE </h1></center>
<center><a href="ajouterTitre.php" class="connexion-btn">Ajouter un autre titre</a></center>
<br><br>
<center><a href="Musimax_ADMIN.html" class="connexion-btn">Revenir à l'accueil</a></center>
</header>

<body>
  <div class="wrapper">
		<h2 class="title">VOS CHOIX</h2>
		<div class="container-fluid">
			<div class="block_line">

				<div class="container-box1 block" id="box"> <!-- PREMIERE BOX -->
        <?php
          // Récupérer les données du formulaire
          $nomArtiste = $_POST['nomArtiste'];
          $titre = $_POST['titre'];
          $duree = $_POST['duree'];

          // Vérifier si le répertoire pour cet artiste existe et le créer si nécessaire
          if (!file_exists($nomArtiste)) {
              mkdir($nomArtiste, 0777, true);
          }

          // Ajouter les données dans le fichier csv correspondant à cet artiste
          $fichier = fopen("$nomArtiste/musicien.csv", "a");
          fputcsv($fichier, array($titre, $duree));
          fclose($fichier);

          // Lire le contenu du fichier csv pour cet artiste et l'afficher
          if (file_exists("$nomArtiste/musicien.csv")) {
              $fichier = fopen("$nomArtiste/musicien.csv", "r");
              echo "<h3>Liste des titres pour $nomArtiste :</h3>";
              echo "<ul>";
              while (($donnees = fgetcsv($fichier, 1000, ";")) !== FALSE) {
                  echo "<li>" . $donnees[0] . " - " . $donnees[1] . " secondes</li>";
              }
              echo "</ul>";
              fclose($fichier);
          }

          // Afficher un lien pour retourner à la page précédente
        ?>
				</div> <!-- FIN PREMIERE BOX -->
			</div>
		</div>
	</div>
</body>
</html>

